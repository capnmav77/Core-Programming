#include <iostream>

using namespace std;

int main ()
{
	int num = 200;

	// Let us display this number in different formats (Dec, Hex and Oct)

	cout << "Decimal val is: " << num << endl;;
	cout << "Hexadecimal value is: " << hex << num << endl;
  	cout << "Hexadecimal value is: " << hex << uppercase << num << endl;
	cout << "Octal value is: " << oct << num << endl;
	
}

