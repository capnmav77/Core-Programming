#include "IntegerListM.h"
#include<vector>

int main() 
{
   std::vector<IntegerList> v;
   v.push_back(IntegerList(25));

  return 0;
}