template <>
class vector <bool>
{
    // interface
 
    private:
    unsigned int *vector_data;
    int length;
    int size;
};